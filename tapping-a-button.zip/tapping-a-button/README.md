# Tapping a button 

A Pen created on CodePen.

Original URL: [https://codepen.io/Aidan-king-the-bold/pen/VYKKzjx](https://codepen.io/Aidan-king-the-bold/pen/VYKKzjx).

